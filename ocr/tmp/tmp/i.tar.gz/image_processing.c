#include <stdio.h>
#include <stdlib.h>

#include <string.h>

#include "image.h"
#include "filter.h"

#include "ocr.h"

char* name;
int main( int argc, char** argv ){

	gdImagePtr src;
	bitmap_ptr bmap;
	
	int i;
	
	char buf[255];
	char buf2[255];
	name = buf;
	
	filter_init();
	ocr_init();
	
	fprintf( stderr, "init finished\n" );

	// open image
	src = open_img( "txt_sample.png" );

	// make bitmap
	bmap = make_bitmap_from_img( src );
	
	fprintf( stderr, "image is loaded\n" );
	
	// pre-processing
	
	fprintf( stderr, "starting find characters\n" );	
	// matching with segmentation
	segmentation( bmap );
	
	fprintf( stderr, "all characters are founded\n" );
	
	destroy_bitmap(bmap);
	gdImageDestroy(src);
	
	// complete

	return 0;

}
