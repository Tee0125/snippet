/*
 *  filter.c
 *  
 *
 *  Created by �¿� �� on 06. 11. 20.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include <stdlib.h>

#include "filter.h"

int __laplace_5[3][3] = {
	 2,	-1,	 2,
	-1,	-4,	-1,
	 2,	 1,	 2
};

int __laplace_6[3][3] = {
	 0,	 1,	 0,
	 1,	-4,	 1,
	 0,	 1,	 0
};

int __laplace_4[3][3] = {
	 1,	 1,	 1,
	 1,	-8,	 1,
	 1,	 1,	 1
};


int __blur[3][3] = {
	 1,	 2,	 1,
	 2,	 4,	 2,
	 1,	 2,	 1
};

int __smooth[3][3] = {
	 1,	 1,	 1,
	 1,	 1,	 1,
	 1,	 1,	 1
};

#if LOG_SIZE == 3
int __log[3][3] = {
	 1,	 2,	 1,
	 2,	-4,	 2,
	 1,	 2,	 1
};
#elif LOG_SIZE == 5
int __log[5][5] = {
	 0,	 0,	-1,	 0,	 0,
	 0,	-1,	-2,	-1,	 0,
	-1,	-2,	16,	-2,	-1,
	 0,	-1,	-2,	-1,	 0,
	 0,	 0,	-1,	 0,	 0
};
#else
#undef LOG_SIZE
#define LOG_SIZE 7

int __log[7][7] = {
	 0,	 0,	-1,	-1,	-1,	 0,	 0,
	 0,	-2,	-3,	-3,	-3,	-2,	 0,
	-1,	-3,	 5,	 5,	 5,	-3,	-1,
	-1,	-3,	 5,	16,	 5,	-3,	-1,
	-1,	-3,	 5,	 5,	 5,	-3,	-1,
	 0,	-2,	-3,	-3,	-3,	-2,	 0,
	 0,	 0,	-1,	-1,	-1,	 0,	 0
};
#endif

void filter_init(){

	int i;

	_laplace = (int**)malloc(sizeof(int*)*3);
	_blur = (int**)malloc(sizeof(int*)*3);
	_smooth = (int**)malloc(sizeof(int*)*3);
	_log = (int**)malloc(sizeof(int*)*LOG_SIZE);

	for( i = 0 ; i < 3 ; i++ ){
		_laplace[i]	= __laplace_4[i];
		_blur[i]	= __blur[i];
		_smooth[i]	= __smooth[i];
		_log[i]		= __log[i];
	}
	for( ; i < LOG_SIZE ; i++ )
		_log[i]		= __log[i];

}

void _img_convolution( gdImagePtr dst, gdImagePtr src, int** w, int wsize, int div ){


	int i, j, k, l;
	
	int h_wsize;
	int pixel;
	int r, g, b;

	h_wsize = wsize/2;
	for( j = 0 ; j < gdImageSY(src) ; j++ ){
		for( i = 0 ; i < gdImageSX(src) ; i++ ){
			
			r = g = b = 0;
			for( k = 0 ; k < wsize ; k++ ){
				for( l = 0 ; l < wsize ; l++ ){

					pixel = get_pixel(src, i-h_wsize+l, j-h_wsize+k);
					
					r += gdImageRed(src, pixel) * w[k][l];
					g += gdImageGreen(src, pixel) * w[k][l];
					b += gdImageBlue(src, pixel) * w[k][l];

				}
			}			
			pixel =  gdImageColorAllocate(dst, r/div, g/div, b/div);
			gdImageSetPixel( dst, i, j, pixel );
			
		}
	}
}


void _bitmap_convolution( bitmap_ptr dst, bitmap_ptr src, int** w, int wsize, int div ){


	int i, j, k, l;
	
	int h_wsize;
	char pixel;

	h_wsize = wsize/2;
	for( j = 0 ; j < src->height ; j++ ){
		for( i = 0 ; i < src->width ; i++ ){
			
			pixel = 0;
			for( k = 0 ; k < wsize ; k++ )
				for( l = 0 ; l < wsize ; l++ )
					pixel += get_bit(src, i-h_wsize+l, j-h_wsize+k) * w[k][l];

			dst->pel[j][i] = pixel/div;
			
		}
	}
}
