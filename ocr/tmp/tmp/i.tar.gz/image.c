/*
 *  image.c
 *  
 *
 *  Created by �¿� �� on 06. 11. 20.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <string.h>

#include "image.h"

bitmap_ptr create_bitmap( int x, int y ){

	bitmap_ptr bmap;
	int j;
	
	bmap = (bitmap_ptr) malloc( sizeof(bitmap) );
	
	bmap->width = x;
	bmap->height = y;
	
	bmap->pel = (int**) malloc( sizeof(int*)*y );
	bmap->pel[0] = (int*) malloc( sizeof(int)*x*y );

	memset( bmap->pel[0], 0, sizeof(int)*x*y );
	for( j = 1 ; j < y ; j++ )
		bmap->pel[j] = bmap->pel[j-1] + x;
		
	return bmap;
	
}

void destroy_bitmap( bitmap_ptr b ){
	free( b->pel[0] );
	free( b->pel );
	free( b );
}

gdImagePtr make_img_from_bitmap( bitmap_ptr src ){

	gdImagePtr img;
	int p, i, j;
	
	img = gdImageCreateTrueColor( src->width, src->height );
	for( j = 0 ; j < src->height ; j++ ){
		for( i = 0 ; i < src->width ; i++ ){
			p = src->pel[j][i];
			p = gdImageColorAllocate( img, p, p, p );
			gdImageSetPixel( img, i, j, p );
		}
	}
	return img;
}


bitmap_ptr make_bitmap_from_img( gdImagePtr src ){

	bitmap_ptr bmap;
	int pixel;
	int new;
	
	int i, j;
	
	bmap = create_bitmap( gdImageSX(src), gdImageSY(src) );
	for( j = 0 ; j < bmap->height ; j++ ){
		for( i = 0 ; i < bmap->width ; i++ ){
			pixel = gdImageGetPixel(src, i, j);
			
			new =  30 * gdImageRed(src,pixel); 
			new += 59 * gdImageGreen(src,pixel); 
			new += 11 * gdImageBlue(src,pixel);
			
			bmap->pel[j][i] = new / 100;
		}
	}
	return bmap;
}

gdImagePtr open_img( char* fname ){

	FILE* in;
	char* ext;
	
	gdImagePtr im = NULL;
	
	ext = strrchr( fname, '.' );
	if( ext == NULL )
		return NULL;
	else 
		ext++;
	
	if( (in = fopen(fname, "rb")) == NULL )
		return NULL;
		
	if( strncasecmp( ext, "jpg", 3 ) == 0 )
		im = gdImageCreateFromJpeg(in);
		
	else if( strncasecmp( ext, "jpeg", 4 ) == 0 )
		im = gdImageCreateFromJpeg(in);
		
	else if( strncasecmp( ext, "gif", 3 ) == 0 )
		im = gdImageCreateFromGif(in);
		
	else if( strncasecmp( ext, "png", 3 ) == 0 )
		im = gdImageCreateFromPng(in);
	
	fclose(in);
	
	return im;
}

void write_img( char* fname, gdImagePtr src ){

	FILE* out;
	char* ext;
	
	ext = strrchr( fname, '.' );
	if( ext == NULL )
		return;
	else 
		ext++;	
		
	out = fopen( fname, "wb" );
	if( strncasecmp( ext, "jpg", 3 ) == 0 )
		gdImageJpeg( src, out, 100);
		
	else if( strncasecmp( ext, "jpeg", 4 ) == 0 )
		gdImageJpeg( src, out, 100);
		
	else if( strncasecmp( ext, "gif", 3 ) == 0 )
		gdImageGif( src, out );
		
	else if( strncasecmp( ext, "png", 3 ) == 0 )
		gdImagePng( src, out );
	
	fclose(out);
	
}

int get_pixel( gdImagePtr src, int x, int y ){
	
	if( x < 0 ){
#ifdef ZERO_PADDING
		return 0;
#else 
		x = 0;
#endif
	}
	else if( x >= gdImageSX(src) ){
#ifdef ZERO_PADDING
		return 0;
#else 
		x = gdImageSX(src)-1;
#endif
	}

	if( y < 0 ){
#ifdef ZERO_PADDING
		return 0;
#else 
		y = 0;
#endif
	}
	else if( y >= gdImageSY(src) ){
#ifdef ZERO_PADDING
		return 0;
#else 
		y = gdImageSY(src)-1;
#endif
	}
	return gdImageGetPixel(src, x, y);

}

int get_bit( bitmap_ptr src, int x, int y ){

	if( x < 0 ){
#ifdef ZERO_PADDING
		return 0;
#else 
		x = 0;
#endif
	}
	else if( x >= src->width ){
#ifdef ZERO_PADDING
		return 0;
#else 
		x = src->width-1;
#endif
	}

	if( y < 0 ){
#ifdef ZERO_PADDING
		return 0;
#else 
		y = 0;
#endif
	}
	else if( y >= src->height ){
#ifdef ZERO_PADDING
		return 0;
#else 
		y = src->height-1;
#endif
	}
	return src->pel[y][x];
	
}


void img_thresholding( gdImagePtr im, int threshold ){

	int i, j;
	int pixel;

	int r, g, b;

	r = g = b = 0;
	for( j = 0 ; j < gdImageSY(im) ; j++ ){

		for( i = 0 ; i < gdImageSX(im) ; i++ ){
			pixel = get_pixel( im, i, j );
			
			r = (gdImageRed(im, pixel) > threshold) ? 255: 0;
			g = (gdImageGreen(im, pixel) > threshold) ? 255: 0;
			b = (gdImageBlue(im, pixel) > threshold) ? 255: 0;

			pixel =  gdImageColorAllocate(im, r, g, b);
			gdImageSetPixel( im, i, j, pixel );

		}
	}
}


void bitmap_thresholding( bitmap_ptr im, int threshold ){

	int i, j;
	int pixel;

	for( j = 0 ; j < im->height ; j++ )
		for( i = 0 ; i < im->width ; i++ )
			im->pel[j][i] = (im->pel[j][i] > threshold)?255:0;

}
