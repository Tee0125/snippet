/*
 *  filter.h
 *  
 *
 *  Created by �¿� �� on 06. 11. 20.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _FILTER_H_
#define _FILTER_H_

#include "image.h"

#define LOG_SIZE	7

int** _laplace;
int** _blur;
int** _smooth;
int** _log;

void filter_init();

void _bitmap_convolution( bitmap_ptr dst, bitmap_ptr src, int** w, int wsize, int div );
void _img_convolution( gdImagePtr dst, gdImagePtr src, int** w, int wsize, int div );

#define filter_laplace(dst,src)	_bitmap_convolution( dst, src, _laplace, 3, 1 )
#define filter_blur(dst,src)	_bitmap_convolution( dst, src, _blur, 3, 16 )
#define filter_smooth(dst,src)	_bitmap_convolution( dst, src, _smooth, 3, 9 )
#define filter_log(dst,src)		_bitmap_convolution( dst, src, _log, LOG_SIZE, 1 )

#endif