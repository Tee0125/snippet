/*
 *  image.h
 *  
 *
 *  Created by �¿� �� on 06. 11. 20.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _IMAGE_H_
#define _IMAGE_H_

#include <gd.h>

#define ZERO_PADDING
#define THRESHOLD 90

struct _bitmap {
	int width;
	int height;
	int** pel;
};

typedef struct _bitmap*	bitmap_ptr;
typedef struct _bitmap	bitmap;

bitmap_ptr create_bitmap( int x, int y );
void destroy_bitmap( bitmap_ptr );

bitmap_ptr make_bitmap_from_img( gdImagePtr src );
gdImagePtr make_img_from_bitmap( bitmap_ptr src );

int  get_pixel( gdImagePtr src, int x, int y );
int get_bit( bitmap_ptr src, int x, int y );

void write_img( char* fname, gdImagePtr src );

void img_thresholding( gdImagePtr im, int threshold );
void bitmap_thresholding( bitmap_ptr im, int threshold );
#endif